# DARK FRUITS — Official Community Website

Premium website for the **Dark Fruits** Blox Fruits Discord community.

**Live Discord invite:** https://discord.gg/jNrBh8EbQ  
**Discadia:** https://dcd.gg/blox-fruits-trading-and-chat-h

---

## Features

- Cinematic dark-purple theme with animated lightning & particles
- Animated logo (GIF) prominently displayed
- Live Discord member & online counters (public API, no tokens)
- Full sections: About, Trading, Giveaways, Tournaments, Events, Bot Features, Staff, Rules
- Mobile-optimised responsive design
- SEO ready (meta tags, Open Graph, sitemap, robots.txt)
- Accessibility: respects `prefers-reduced-motion`

---

## Free Deployment on Cloudflare Pages

### Option A — GitHub + Cloudflare (recommended)

1. Create a free GitHub account if you don’t have one: https://github.com
2. Create a **new public repository** named `dark-fruits` (or `dark-fruits-website`)
3. Upload **all** files and the `assets` folder (keep structure):
   - `index.html`
   - `robots.txt`
   - `sitemap.xml`
   - `README.md`
   - `assets/` (contains the logo GIF, JPG, and favicons)
4. Go to https://dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
5. Select your repository
6. Build settings:
   - Framework preset: **None**
   - Build command: *(leave empty)*
   - Build output directory: `/` (or leave default / root)
7. Deploy
8. Cloudflare will give you a free `*.pages.dev` address  
   Desired names: `dark-fruits.pages.dev` or `darkfruits-community.pages.dev`

Every time you push changes to the GitHub repo, Cloudflare automatically redeploys.

### Option B — Direct upload (no Git)

1. In Cloudflare Pages → Create project → **Upload assets**
2. Drag the entire contents of this folder (including the `assets` folder)
3. Deploy

---

## Updating Content Later

- **Member count** updates automatically from Discord’s public invite API.
- To change staff, rules, or text: edit `index.html` and redeploy.
- To replace the logo: replace `assets/dark-fruits-logo.gif` (keep the same filename).

---

## Notes

- No paid services or domains required.
- No bot tokens or private credentials are used or exposed.
- The live counter falls back gracefully if Discord is unreachable.
- Unofficial fan community — not affiliated with Roblox or Blox Fruits developers.
